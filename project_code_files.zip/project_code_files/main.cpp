





// game screen & balloon with hit detection


#if 1
#include "BALLOON.hpp"

#include "tasks.hpp"
#include "examples/examples.hpp"
#include "LPC17xx.h"
#include "FreeRTOS.h"
#include "stdio.h"
#include "uart0_min.h"

#include "storage.hpp"
#include "event_groups.h"
#include <string.h>

#define DEMO    0

TaskHandle_t TaskHandle_1;
TaskHandle_t TaskHandle_2;
TaskHandle_t TaskHandle_3;

arrow one(2, 4, 0, 3);
gballoon balloon1 (9, 3, 8, 1, 2);
gballoon balloon2 (10, 3, 8, 3, 1);
BALLOON sjone(DEMO);
int flag_1 = 0;
int flag_2 = 0;
void switch_init(void)
{
    //Switch 0 at P1.9
    LPC_PINCON->PINSEL2 &= ~(0x3 << 18);            //Set as GPIO pin
    LPC_GPIO1->FIODIR &= ~(1 << 9);                 //Set switch as input

    //Switch 1 at P1.10
    LPC_PINCON->PINSEL2 &= ~(0x3 << 20);
    LPC_GPIO1->FIODIR &= ~(1 << 10);

    //Switch 2 at P1.14
    LPC_PINCON->PINSEL2 &= ~(0x3 << 28);
    LPC_GPIO1->FIODIR &= ~(1 << 14);

    //Switch external at P1.19
    LPC_PINCON -> PINSEL3 &= ~(0x3 << 6);
    LPC_GPIO1 -> FIODIR &= ~(1<<19);
}

void moveArrow(void *params)
{
    printf("inside interrupt\n");
    int count = 0;
    int score = 0;

    while(1){
        sjone.gamescreen(score);
        sjone.displayArrow(one);
        int16_t yVal = Acceleration_Sensor::getInstance().getY();
                        if (yVal > 200 )
                        {
                            delay_ms(30);
                            one.incrementRow();
                            //    printf("Row: %d\n",one.getRow());
                        }


                        if (yVal < -200 )
                        {
                            delay_ms(30);
                            one.decrementRow();
                            //      printf("Row: %d\n",one.getRow());
                        }

            if((LPC_GPIO1->FIOPIN & (1 << 19)) && count < 10)
            {
                    //shoot arrow
                count++;

                while(one.getColumn() < 18 ){
                    sjone.gamescreen(score);
                    sjone.displayArrow(one);
                    one.incrementarrowCol();

                    if( (one.getRow() ==  balloon1.getRow() || one.getRow() ==  balloon1.getRow()+1 || one.getRow() ==  balloon1.getRow()+2)   && ( (one.getColumn() + 3) == (balloon1.getColumn()) ) )
                    {
                        balloon1.setColor(0);
                        balloon1.setRow(0);
                        score++;
                      //  flag_1 = 1;
                        one.resetArrowCol();
                        break;
                        delay_ms(10);
                    }
                    if( (one.getRow() ==  balloon2.getRow() || one.getRow() ==  balloon2.getRow()+1 || one.getRow() ==  balloon2.getRow()+2)   && ( (one.getColumn() + 3) == (balloon2.getColumn()) ) )
                    {
                        balloon2.setColor(0);
                        balloon2.setRow(0);
                        score++;
                        //flag_2 = 1;
                        one.resetArrowCol();
                        delay_ms(10);
                        break;
                    }
                    printf("%d \n",score);
                    sjone.gamescreen(score);
                    delay_ms(10); // delay for controlling the speed of arrow
                }
                one.resetArrowCol();


            }
            if (count == 10 ){
                sjone.stopscreen();
                sjone.gamescreen(score);
                one.setColor(0);
                balloon1.setColor(0);
                balloon2.setColor(0);
                vTaskSuspend(TaskHandle_3);
                vTaskSuspend(TaskHandle_2);
            }
//            if((LPC_GPIO1->FIOPIN & (1 << 19)) && count ==10){
//                delay_ms(1000);
//                vTaskResume(TaskHandle_3);
//                vTaskResume(TaskHandle_2);
//                score =0;
//                count =0;
//            }

    }
}


void moveBalloon1(void *params)
{

    int random = 0 ;
    while(1)
    {
 //       sjone.gamescreen();

        balloon1.setColor(1);
        random = rand()%8 + 4  ;
        balloon1.setColumn(random);
        for (int i = 0; i < 16; i++) {

            balloon1.setRow(i);
            sjone.displayBalloon(balloon1);


            balloon1.setRow(i + 1);
            sjone.displayBalloon(balloon1);

            balloon1.setRow(i + 2);
            sjone.displayBalloon(balloon1);
            sjone.displayArrow(one);
            delay_ms(30);


        }

    }
}



void moveBalloon2(void *params)
{
    int random;
    int flag =0;


        while(1)
        {

            vTaskSuspend(TaskHandle_1);
            vTaskSuspend(TaskHandle_2);
            sjone.startscreen();
            if(LPC_GPIO1->FIOPIN & (1 << 19)) //19 for external s/w
            {
                delay_ms(1500);
                break;
            }
        }
         while(1){
                sjone.levelScreen();

                sjone.displayArrow(one);
                int16_t yVal = Acceleration_Sensor::getInstance().getY();
                if (yVal > 350 )
                {
                    delay_ms(10);
                    one.incrementRow();

                }


                if (yVal < -350 )
                {
                    delay_ms(10);
                    one.decrementRow();

                }
                if((LPC_GPIO1->FIOPIN & (1 << 19)) )
                {

                    while(one.getColumn() < 18 )
                    {
                        sjone.levelScreen();
                        sjone.displayArrow(one);
                        one.incrementarrowCol();

                        if( (one.getRow() >=  1) && (one.getRow() <= 6)  && (one.getColumn() == 6) )
                        {
                            // level 1 selected
                            delay_ms(1000);
                            vTaskResume(TaskHandle_1);
                            flag =1;
                            break;

                        }
                        if( (one.getRow() >=  9) && (one.getRow() <= 14)  && (one.getColumn() == 8) )
                        {
                            // level 2 selected
                            delay_ms(1000);
                            vTaskResume(TaskHandle_1);
                            vTaskResume(TaskHandle_2);
                            flag =1;
                            break;

                        }

                    }
                }

                if(flag == 1){

                break;
                }
            }

 while(1){
  //  sjone.gamescreen(score);
    balloon2.setColor(3);
    random = rand()%8 + 8  ;
    balloon2.setColumn(random);
    for (int i = 0; i < 16; i++) {

                balloon2.setRow(i);
                sjone.displayBalloon(balloon2);
                // Balloon Line 2
                balloon2.setRow(i + 1);
                sjone.displayBalloon(balloon2);

                balloon2.setRow(i + 2);
                sjone.displayBalloon(balloon2);

                sjone.displayArrow(one);
                delay_ms(30);
       //         sjone.gamescreen();
            }

    }

    }
int main(void)
{
    const uint32_t STACK_SIZE = 1024;

    switch_init();
    sjone.initRGB();
    xTaskCreate(moveArrow, "Move Arrow", STACK_SIZE, NULL, 3, &TaskHandle_1);
    xTaskCreate(moveBalloon1,"Moving Balloon1", STACK_SIZE, NULL, 3,&TaskHandle_2);
    xTaskCreate(moveBalloon2,"Moving Balloon2", STACK_SIZE, NULL, 3,&TaskHandle_3);

    vTaskStartScheduler();
    return 0;
}
#endif





