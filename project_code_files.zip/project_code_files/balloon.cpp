
#include "BALLOON.hpp"

BALLOON::BALLOON (bool debug = false) : m_debug(debug) {}
BALLOON::~BALLOON () {}

void BALLOON::initRGB(void)
{
    if(m_debug) printf("Initializing SJOne...\n");

    // Select GPIO Port 0.0, 0.1 pin-select functionality
    LPC_PINCON->PINSEL0 &= ~(0x4);
    LPC_GPIO0->FIODIR |= (1 << LAT);    // P0.1 -> LAT
    LPC_GPIO0->FIODIR |= (1 << OE);     // P0.0 -> OE
    LPC_GPIO0->FIOSET = (1 << OE);
    LPC_GPIO0->FIOCLR = (1 << LAT);

    // Select GPIO Port 2.0, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8 pin-select functionality
    LPC_PINCON->PINSEL4 &= ~(0x3FFFF);
    LPC_GPIO2->FIODIR |= (1 << R1);     // P2.0 -> R1
    LPC_GPIO2->FIODIR |= (1 << G1);     // P2.1 -> G1
    LPC_GPIO2->FIODIR |= (1 << B1);     // P2.2 -> B1
    LPC_GPIO2->FIODIR |= (1 << R2);     // P2.3 -> R2
    LPC_GPIO2->FIODIR |= (1 << G2);     // P2.4 -> G2
    LPC_GPIO2->FIODIR |= (1 << B2);     // P2.5 -> B2

    // Select GPIO Port 1.20 pin-select functionality
    LPC_PINCON->PINSEL3 &= ~(3 << 8);
    LPC_GPIO1->FIODIR |= (1 << CLK);      // P1.20 -> CLK
    LPC_GPIO1->FIOCLR = (1 << CLK);

    LPC_GPIO2->FIODIR |= (1 << A);      // P2.6 -> A
    LPC_GPIO2->FIODIR |= (1 << B);      // P2.7 -> B
    LPC_GPIO2->FIODIR |= (1 << C);      // P2.8 -> C
    LPC_GPIO2->FIOPIN &= ~(0x1FF);


 //   vTaskDelay(100);
}

void BALLOON::startscreen(void)
{
    char start[16][32] =

    {
           //          H           i        t                    T           h           e
          {0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
          {0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0},
          {0, 0, 2, 0, 0, 0, 2, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 2, 2, 0, 0, 0},
          {0, 0, 2, 2, 2, 2, 2, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 2, 2, 0, 2, 0, 0, 0, 0, 0},
          {0, 0, 2, 0, 0, 0, 2, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 2, 0, 2, 2, 2, 0, 0, 0},
          {0, 0, 2, 0, 0, 0, 2, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 2, 0, 2, 0, 0, 0, 0, 0},
          {0, 0, 2, 0, 0, 0, 2, 0, 2, 0, 0, 2, 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 2, 0, 2, 2, 2, 0, 0, 0},
          {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
          //       B             a             l     l        o           o        n
          {0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
          {0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
          {0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
          {0, 0, 2, 2, 2, 0, 0, 0, 2, 2, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
          {0, 0, 2, 0, 0, 2, 0, 2, 0, 0, 2, 0, 2, 0, 2, 0, 2, 2, 2, 0, 2, 2, 2, 0, 2, 2, 2, 0, 0, 0, 0, 0},
          {0, 0, 2, 0, 0, 2, 0, 2, 2, 2, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 0, 0, 0, 0, 0},
          {0, 0, 2, 2, 2, 0, 0, 2, 0, 0, 2, 0, 2, 0, 2, 0, 2, 2, 2, 0, 2, 2, 2, 0, 2, 0, 2, 0, 0, 0, 0, 0},
          {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
        };
    for(uint8_t row = 0; row < 8; ++row)
    {
        disableOE();
        set_color_top(0);
        set_color_bottom(0);
        set_row(row);
        for(uint8_t col = 0; col < 32; ++col)
        {


                set_color_top(start[row+8][col]);
                set_color_bottom(start[row][col]);
                //set_color_top(1);
                //set_color_bottom(1);

            clockTick();
        }
        latchReset();
        enableOE();
      //  vTaskDelay(1);
        delay_us(300);
    }
}


void BALLOON::stopscreen(void)
{
    char stop[16][32] =
    {
               //          S           c        o            r        e
            {0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 2, 2, 2, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 2, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 2, 2, 2, 0, 2, 2, 2, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 2, 0, 2, 0, 2, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 2, 2, 2, 0, 0, 0, 2, 2, 0, 2, 2, 2, 0, 2, 0, 2, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},

            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
            };

    for(uint8_t row = 0; row < 8; ++row)
        {
            disableOE();
            set_color_top(0);
            set_color_bottom(0);
            set_row(row);
            for(uint8_t col = 0; col < 32; ++col)
            {

                    set_color_top(stop[row+8][col]);
                    set_color_bottom(stop[row][col]);
                    //set_color_top(1);
                    //set_color_bottom(1);

                clockTick();
            }
            latchReset();
            enableOE();
         //   vTaskDelay(1);
            delay_us(300); //less delay less bright & vice versa
        }
    }


void BALLOON::gamescreen(int score)
{
    char gamescreen[16][32] =
    {
               //          S           c        o            r        e
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},

            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
            };

    switch(score)
        {case 0:
        {
            gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
            gamescreen[5][27]+='a';gamescreen[5][30]+='a';
            gamescreen[6][27]+='a';gamescreen[6][30]+='a';
            gamescreen[7][27]+='a';gamescreen[7][30]+='a';
            gamescreen[8][27]+='a';gamescreen[8][30]+='a';
            gamescreen[9][27]+='a';gamescreen[9][30]+='a';
            gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        case 1:
        {
            gamescreen[4][27]+='a';
            gamescreen[5][27]+='a';
            gamescreen[6][27]+='a';
            gamescreen[7][27]+='a';
            gamescreen[8][27]+='a';
            gamescreen[9][27]+='a';
            gamescreen[10][27]+='a';
        }break;
        case 2:
        {
            gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
            gamescreen[5][30]+='a';
            gamescreen[6][30]+='a';
            gamescreen[7][27]+='a';gamescreen[5][28]+='a';gamescreen[4][29]+='a';gamescreen[7][30]+='a';
            gamescreen[8][27]+='a';
            gamescreen[9][27]+='a';
            gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        case 3:
        {
            gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
            gamescreen[5][30]+='a';
            gamescreen[6][30]+='a';
            gamescreen[7][27]+='a';gamescreen[7][28]+='a';gamescreen[7][29]+='a';gamescreen[7][30]+='a';
            gamescreen[8][30]+='a';
            gamescreen[9][30]+='a';
            gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        case 4:
        {
            gamescreen[4][27]+='a';gamescreen[4][30]+='a';
            gamescreen[5][27]+='a';gamescreen[5][30]+='a';
            gamescreen[6][27]+='a';gamescreen[6][30]+='a';
            gamescreen[7][27]+='a';gamescreen[7][28]+='a';gamescreen[7][29]+='a';gamescreen[7][30]+='a';
            gamescreen[8][30]+='a';
            gamescreen[9][30]+='a';
            gamescreen[10][30]+='a';
        }break;
        case 5:
        {
            gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
            gamescreen[5][27]+='a';
            gamescreen[6][27]+='a';
            gamescreen[7][27]+='a';gamescreen[7][28]+='a';gamescreen[7][29]+='a';gamescreen[7][30]+='a';
            gamescreen[8][30]+='a';
            gamescreen[9][30]+='a';
            gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        case 6:
        {
            gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
            gamescreen[5][27]+='a';
            gamescreen[6][27]+='a';
            gamescreen[7][27]+='a';gamescreen[7][28]+='a';gamescreen[7][29]+='a';gamescreen[7][30]+='a';
            gamescreen[8][27]+='a';gamescreen[8][30]+='a';
            gamescreen[9][27]+='a';gamescreen[9][30]+='a';
            gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        case 7:
        {   gamescreen[4][26]+='a';
            gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
            gamescreen[5][29]+='a';
            gamescreen[6][28]+='a';
            gamescreen[7][27]+='a';
            gamescreen[8][26]+='a';
         }break;
        case 8:
        {
            gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
            gamescreen[5][27]+='a';gamescreen[5][30]+='a';
            gamescreen[6][27]+='a';gamescreen[6][30]+='a';
            gamescreen[7][27]+='a';gamescreen[7][28]+='a';gamescreen[7][29]+='a';gamescreen[7][30]+='a';
            gamescreen[8][27]+='a';gamescreen[8][30]+='a';
            gamescreen[9][27]+='a';gamescreen[9][30]+='a';
            gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        case 9:
        {
            gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
            gamescreen[5][27]+='a';gamescreen[5][30]+='a';
            gamescreen[6][27]+='a';gamescreen[6][30]+='a';
            gamescreen[7][27]+='a';gamescreen[7][28]+='a';gamescreen[7][29]+='a';gamescreen[7][30]+='a';
            gamescreen[8][30]+='a';
            gamescreen[9][30]+='a';
            gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        case 10:
        {
            gamescreen[4][25]+='a';
            gamescreen[5][25]+='a';
                    gamescreen[6][25]+='a';
                    gamescreen[7][25]+='a';
                    gamescreen[8][25]+='a';
                    gamescreen[9][25]+='a';
                    gamescreen[10][25]+='a';
                    gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
                            gamescreen[5][27]+='a';gamescreen[5][30]+='a';
                            gamescreen[6][27]+='a';gamescreen[6][30]+='a';
                            gamescreen[7][27]+='a';gamescreen[7][30]+='a';
                            gamescreen[8][27]+='a';gamescreen[8][30]+='a';
                            gamescreen[9][27]+='a';gamescreen[9][30]+='a';
                            gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        case 11:
        {
            gamescreen[4][25]+='a';
            gamescreen[4][25]+='a';
                            gamescreen[6][25]+='a';
                            gamescreen[7][25]+='a';
                            gamescreen[8][25]+='a';
                            gamescreen[9][25]+='a';
                            gamescreen[10][25]+='a';
                            gamescreen[4][27]+='a';
                            gamescreen[4][27]+='a';
                            gamescreen[6][27]+='a';
                            gamescreen[7][27]+='a';
                            gamescreen[8][27]+='a';
                            gamescreen[9][27]+='a';
                            gamescreen[10][27]+='a';
        }break;
        case 12:
        {gamescreen[4][25]+='a';
        gamescreen[4][25]+='a';
        gamescreen[6][25]+='a';
        gamescreen[7][25]+='a';
        gamescreen[8][25]+='a';
        gamescreen[9][25]+='a';
        gamescreen[10][25]+='a';
        gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
                gamescreen[5][30]+='a';
                gamescreen[6][30]+='a';
                gamescreen[7][27]+='a';gamescreen[5][27]+='a';gamescreen[4][27]+='a';gamescreen[7][30]+='a';
                gamescreen[8][27]+='a';
                gamescreen[9][27]+='a';
                gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        case 13:
        {gamescreen[4][25]+='a';
        gamescreen[4][25]+='a';
        gamescreen[6][25]+='a';
        gamescreen[7][25]+='a';
        gamescreen[8][25]+='a';
        gamescreen[9][25]+='a';
        gamescreen[10][25]+='a';
        gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
        gamescreen[5][30]+='a';
        gamescreen[6][30]+='a';
        gamescreen[7][27]+='a';gamescreen[7][28]+='a';gamescreen[7][29]+='a';gamescreen[7][30]+='a';
        gamescreen[8][30]+='a';
        gamescreen[9][30]+='a';
        gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        case 14:
        {gamescreen[4][25]+='a';
        gamescreen[4][25]+='a';
        gamescreen[6][25]+='a';
        gamescreen[7][25]+='a';
        gamescreen[8][25]+='a';
        gamescreen[9][25]+='a';
        gamescreen[10][25]+='a';
        gamescreen[4][27]+='a';gamescreen[4][30]+='a';
        gamescreen[5][27]+='a';gamescreen[5][30]+='a';
        gamescreen[6][27]+='a';gamescreen[6][30]+='a';
        gamescreen[7][27]+='a';gamescreen[7][28]+='a';gamescreen[7][29]+='a';gamescreen[7][30]+='a';
        gamescreen[8][30]+='a';
        gamescreen[9][30]+='a';
        gamescreen[10][30]+='a';
        }break;
        case 15:
        {gamescreen[4][25]+='a';
        gamescreen[4][25]+='a';
        gamescreen[6][25]+='a';
        gamescreen[7][25]+='a';
        gamescreen[8][25]+='a';
        gamescreen[9][25]+='a';
        gamescreen[10][25]+='a';
        gamescreen[4][27]+='a';gamescreen[4][28]+='a';gamescreen[4][29]+='a';gamescreen[4][30]+='a';
                gamescreen[5][27]+='a';
                gamescreen[6][27]+='a';
                gamescreen[7][27]+='a';gamescreen[7][28]+='a';gamescreen[7][29]+='a';gamescreen[7][30]+='a';
                gamescreen[8][30]+='a';
                gamescreen[9][30]+='a';
                gamescreen[10][27]+='a';gamescreen[10][28]+='a';gamescreen[10][29]+='a';gamescreen[10][30]+='a';
        }break;
        }



    for(uint8_t row = 0; row < 8; row++)
        {
            disableOE();
            set_color_top(0);
            set_color_bottom(0);
            set_row(row);
            for(uint8_t col = 0; col < 32; ++col)
            {
                set_color_top(gamescreen[row+8][col]); //  top means bottom half of matrix
                set_color_bottom(gamescreen[row][col]); // bottom means top half of matrix
                    //set_color_top(1);
                    //set_color_bottom(1);

                clockTick();
            }

            latchReset();
            enableOE();
          //  vTaskDelay(1);
            delay_us(500);
        }
    }

void BALLOON:: levelScreen(void){
    char levelscreen[16][32] =
        {
                   //          S           c        o            r        e
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 3, 0, 0, 0, 3, 0, 0, 0, 3, 0, 0, 5, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 3, 0, 0, 0, 0, 3, 0, 3, 0, 0, 0, 5, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 3, 3, 3, 0, 0, 0, 3, 0, 0, 0, 0, 5, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},

                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 3, 0, 0, 0, 3, 0, 0, 0, 3, 5, 0, 5, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 3, 0, 0, 0, 0, 3, 0, 3, 0, 0, 5, 5, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 3, 3, 3, 0, 0, 0, 3, 0, 0, 5, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                };

        for(uint8_t row = 0; row < 8; row++)
            {
                disableOE();
                set_color_top(0);
                set_color_bottom(0);
                set_row(row);
                for(uint8_t col = 0; col < 32; ++col)
                {
                    set_color_top(levelscreen[row+8][col]); //  top means bottom half of matrix
                    set_color_bottom(levelscreen[row][col]); // bottom means top half of matrix
                        //set_color_top(1);
                        //set_color_bottom(1);

                    clockTick();
                }

                latchReset();
                enableOE();
              //  vTaskDelay(1);
                delay_us(200);
            }

}


void BALLOON::displayArrow(arrow &test)
{
    //arrow *object;
    //object = &test;

    /*uint8_t arrow_row = 2;
    uint8_t arrow_length = 4;
    uint8_t arrow_color = 1;
    uint8_t arrow_position = 0;*/

    for(uint8_t row = 0; row < 16; ++row)
    {
        disableOE();
        set_color_top(0);
        set_color_bottom(0);
        set_row(row);
        for(uint8_t col = 0; col < 32; ++col)
        {
            /* Correct way to set
            set_color_top(splash[row+8][col]);
            set_color_bottom(splash[row][col]);
             */
            if(test.getRow() == row)
            {
                if((col >= test.getColumn() && (col < (test.getLength() + test.getColumn()))))
                {
                    if(test.getRow() < 8)
                    {
                        set_color_bottom(test.getColor());
                        set_color_top(0);

                    }
                    else
                    {
                        set_color_top(test.getColor());
                        set_color_bottom(0);
                    }
                  //  clockTick();
                }
                else
                {
                    set_color_top(0);
                    set_color_bottom(0);
                }
            }
            clockTick();
        }
        latchReset();
        enableOE();
            delay_us(200);
//        vTaskDelay(0.1);

    }
}


void BALLOON::displayBalloon(gballoon &test2)
{
    for(int8_t row = 0; row < 16; ++row)
        {
            disableOE();
            set_color_top(0);
            set_color_bottom(0);
            set_row(row);
            for(uint8_t col = 0; col < 32; ++col)                                                                                                    // +
            {
//                    if((col >= test2.getColumn() && (col < (test2.getLength() + test2.getColumn())))&&(row >= test2.getRow())&&(row < test2.getRow()+test2.getHeight()))
                if((col >= test2.getColumn() && (col < (test2.getLength() + test2.getColumn())))&&(row <= test2.getRow())&&(row > test2.getRow()-test2.getHeight()))
                {
                        if(test2.getRow() < 8)
                        {
                            set_color_bottom(test2.getColor());
                            set_color_top(0);

                        }

                        else
                        {
                            set_color_top(test2.getColor());
                            set_color_bottom(0);

                        }

                    }
                    else
                    {
                        set_color_top(0);
                        set_color_bottom(0);

                    }
                clockTick();
            }
            latchReset();
            enableOE();
               delay_us(300);

     //       vTaskDelay(0.1);
               }

}



void BALLOON::enableOE(void)
{
    LPC_GPIO0->FIOCLR = (1 << OE);
}

void BALLOON::disableOE(void)
{
    LPC_GPIO0->FIOSET = (1 << OE);
}

void BALLOON::clockTick(void)
{
    LPC_GPIO1->FIOSET = (1 << CLK);
    LPC_GPIO1->FIOCLR = (1 << CLK);
}

void BALLOON::latchReset(void)
{
    LPC_GPIO0->FIOSET = (1 << LAT);
    LPC_GPIO0->FIOCLR = (1 << LAT);
}

void BALLOON::set_row(uint8_t row)
{
    uint8_t a_bit = row & 1;
    uint8_t b_bit = (row >> 1) & 1;
    uint8_t c_bit = (row >> 2) & 1;
    a_bit ? LPC_GPIO2->FIOSET = (1 << A) : LPC_GPIO2->FIOCLR = (1 << A);
    b_bit ? LPC_GPIO2->FIOSET = (1 << B) : LPC_GPIO2->FIOCLR = (1 << B);
    c_bit ? LPC_GPIO2->FIOSET = (1 << C) : LPC_GPIO2->FIOCLR = (1 << C);
}

void BALLOON::set_color_bottom(uint32_t color)
{

        uint8_t r2_bit = color & 1;
        uint8_t g2_bit = (color >> 1) & 1;
        uint8_t b2_bit = (color >> 2) & 1;
        r2_bit ? LPC_GPIO2->FIOSET = (1 << R2) : LPC_GPIO2->FIOCLR = (1 << R2);
        g2_bit ? LPC_GPIO2->FIOSET = (1 << G2) : LPC_GPIO2->FIOCLR = (1 << G2);
        b2_bit ? LPC_GPIO2->FIOSET = (1 << B2) : LPC_GPIO2->FIOCLR = (1 << B2);

}

void BALLOON::set_color_top(uint32_t color)
{

        uint8_t r1_bit = color & 1;
        uint8_t g1_bit = (color >> 1) & 1;
        uint8_t b1_bit = (color >> 2) & 1;
        r1_bit ? LPC_GPIO2->FIOSET = (1 << R1) : LPC_GPIO2->FIOCLR = (1 << R1);
        g1_bit ? LPC_GPIO2->FIOSET = (1 << G1) : LPC_GPIO2->FIOCLR = (1 << G1);
        b1_bit ? LPC_GPIO2->FIOSET = (1 << B1) : LPC_GPIO2->FIOCLR = (1 << B1);
    }

