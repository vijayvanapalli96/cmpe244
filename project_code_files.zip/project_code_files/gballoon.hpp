/*
 * gballoon.hpp
 *
 *  Created on: 03-Dec-2018
 *      Author: RohanRahul
 */

#ifndef GBALLOON_HPP_
#define GBALLOON_HPP_

#include <stdint.h>

class gballoon
{
public:
    gballoon(volatile int8_t row_num, uint8_t arrow_length,volatile uint8_t col_pos, uint8_t color_typ, int8_t height_bal);
    ~gballoon();
    uint8_t getRow(void);
    uint8_t getLength(void);
    uint8_t getColumn(void);
    uint8_t getColor(void);
    uint8_t getHeight(void);
    void incrementRow(void);
    void decrementRow(void);
    void setRow(int);
    void setColumn(int);
    void setColor(uint8_t newColor);


private:
    uint8_t row;
    uint8_t length;
    uint8_t color;
    uint8_t column;
    uint8_t height;
};




#endif /* GBALLOON_HPP_ */
