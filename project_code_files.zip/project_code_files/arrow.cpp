/*
 * arrow.cpp
 *
 *  Created on: 25-Nov-2018
 *      Author: RohanRahul
 */

#include "arrow.hpp"
#include "utilities.h"


arrow::arrow(volatile uint8_t row_num, uint8_t arrow_length, volatile uint8_t col_pos, uint8_t color_typ)
{
    row = row_num;
    length = arrow_length;
    column = col_pos;
    color = color_typ;
}

arrow::~arrow()
{
}

uint8_t arrow::getRow(void)
{
    return row;
}

uint8_t arrow::getLength(void)
{
   // column = length;
    return length;
}

uint8_t arrow::getColumn(void)
{
    return column;
}

uint8_t arrow::getColor(void)
{
 //   column = length;
    return color;
}

void arrow::resetArrowCol(void){
    column = 0;
}

void arrow::setColor(uint8_t newColor)
{
    color = newColor;
}

void arrow::incrementRow(void)
{
    if(row < 13)
    {
        row++;
    }
    else
    {
        row = 2;
    }
}

void arrow::decrementRow(void)
{
    if(2 == row)
    {
        row = 13;
    }
    else
    {
        row--;
    }
}

void arrow::incrementarrowCol(void){
    column++;
}


void arrow::shootarrow(void)
{

    while (column < 18 )
    {
        column++;
        delay_ms(50);
    }
   column = 0;
}





