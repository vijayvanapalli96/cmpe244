///*
// * balloon.hpp
// *
// *  Created on: 25-Nov-2018
// *      Author: RohanRahul
// */
//
//#ifndef BALLOON_HPP_
//#define BALLOON_HPP_
//
//#include "tasks.hpp"
//#include "examples/examples.hpp"
//#include "LPC17xx.h"
//#include "FreeRTOS.h"
//#include "stdio.h"
//#include "uart0_min.h"
//#include "light_sensor.hpp"
//#include "storage.hpp"
//#include "event_groups.h"
//#include <string.h>
//#include <inttypes.h>
//
//#include "acceleration_sensor.hpp"
//
//
//
//class BALLOON
//{
//public:
//
//    // Port 2
//    enum RGB_PIN
//    {
//        R1 = 0,
//        G1 = 1,
//        B1 = 2,
//        R2 = 3,
//        G2 = 4,
//        B2 = 5,
//        A = 6,
//        B = 7,
//        C = 8,
//    };
//    // Port 0
//    enum MATRIX_PIN
//    {
//        LAT = 1,
//        OE = 0,
//        CLK = 20,
//    };
//
//
//    uint8_t m_matrixWidth;
//    uint8_t m_matrixHeight;
//
//    bool convert_i = 0;
//    bool convert_j = 0;
//
//    BALLOON(bool);
//    ~BALLOON();
//
//    //Hit the balloon
//    void initRGB(void);
//    void arrow(int test);
//
//
//    void splashscreen(void);
//    void generateballoon(void);
//
//
//    void enableOE(void);
//    void disableOE(void);
//    void clockTick(void);
//    void latchReset(void);
//    void set_row(uint8_t);
//    void set_color_top(uint32_t);
//    void set_color_bottom(uint32_t);
//
//    uint8_t getRow(void);
//    uint8_t getLength(void);
//    uint8_t getColumn(void);
//    uint8_t getColor(void);
//    void incrementRow(void);
//    void decrementRow(void);
//    void shoot_arrow(void);
//
//    volatile uint8_t  m_matrixBuffer[16][32];
//
//    bool m_debug;
//
//};
//
////class arrow
////{
////public:
////    arrow(volatile uint8_t row_num, uint8_t arrow_length, uint8_t col_pos, uint8_t color_typ);
////    ~arrow();
////    uint8_t getRow(void);
////    uint8_t getLength(void);
////    uint8_t getColumn(void);
////    uint8_t getColor(void);
////    void incrementRow(void);
////    void decrementRow(void);
////    void shoot_arrow(void);
////    void displayArrow(arrow &test);
////
////private:
////    uint8_t row;
////    uint8_t length;
////    uint8_t color;
////    uint8_t column;
////};
//
//
//
//#endif /* BALLOON_HPP_ */





#ifndef BALLOON_HPP_
#define BALLOON_HPP_

#include "tasks.hpp"
#include "LPC17xx.h"
#include "FreeRTOS.h"
#include "stdio.h"
#include <string.h>

#include "acceleration_sensor.hpp"
#include "utilities.h"
#include "arrow.hpp"
#include "gballoon.hpp"

extern SemaphoreHandle_t xMutex;

class BALLOON
{
private:

public:
    // Port 2
    enum RGB_PIN
    {
        R1 = 0,
        G1 = 1,
        B1 = 2,
        R2 = 3,
        G2 = 4,
        B2 = 5,
        A = 6,
        B = 7,
        C = 8,
    };
    // Port 0
    enum MATRIX_PIN
    {
        LAT = 1,
        OE = 0,
        CLK = 20,
    };




    BALLOON(bool);
    ~BALLOON();

    void initRGB(void);
    void startscreen(void);
    void stopscreen(void);
    void displayArrow(arrow &test1);
    void displayBalloon(gballoon &test2);
    void displayBalloonMatrix(void);
    void gamescreen(int score);
    void levelScreen(void);


    void enableOE(void);
    void disableOE(void);
    void clockTick(void);
    void latchReset(void);
    void set_row(uint8_t);
    void set_color_top(uint32_t);
    void set_color_bottom(uint32_t);


    bool m_debug;
};

#endif /* BALLOON_HPP_ */
