/*
 * gballoon.cpp
 *
 *  Created on: 03-Dec-2018
 *      Author: RohanRahul
 */
#include "gballoon.hpp"
#include "utilities.h"

gballoon::gballoon(volatile int8_t row_num, uint8_t gballoon_length, volatile uint8_t col_pos, uint8_t color_typ, int8_t height_bal)
{
    row = row_num;
    length = gballoon_length;
    column = col_pos;
    color = color_typ;
    height = height_bal;
}

gballoon::~gballoon()
{
}

uint8_t gballoon::getRow(void)
{
    return row;
}

uint8_t gballoon::getLength(void)
{
    return length;
}

uint8_t gballoon::getHeight(void)
{
    return height;
}

uint8_t gballoon::getColumn(void)
{
    return column;
}

uint8_t gballoon::getColor(void)
{
    return color;
}

void gballoon::incrementRow(void)
{
    if(row < 15)
    {
        row++;
    }
    else
    {
        row = 0;
    }
  //  delay_ms(300);
}

void gballoon::setRow(int a){
    row = a;

}

void gballoon::setColumn(int a){
    column = a;

}

void gballoon::decrementRow(void)
{
    if(0 == row)
    {
        row = 15;
    }
    else
    {
        row--;
    }
  //  delay_ms(100);
}

void gballoon::setColor(uint8_t newColor)
{
    color = newColor;
}





