/*
 * arrow.hpp
 *
 *  Created on: 25-Nov-2018
 *      Author: RohanRahul
 */

#ifndef ARROW_HPP_
#define ARROW_HPP_

#include <stdint.h>
#include "tasks.hpp"
#include "FreeRTOS.h"
#include <stdio.h>

class arrow
{
public:
    arrow(volatile uint8_t row_num, uint8_t arrow_length,volatile uint8_t col_pos, uint8_t color_typ);
    ~arrow();
    uint8_t getRow(void);
    uint8_t getLength(void);
    uint8_t getColumn(void);
    uint8_t getColor(void);
    void incrementRow(void);
    void decrementRow(void);
    void shootarrow(void);
    void resetArrowCol(void);
    void setColor(uint8_t newColor);
    void incrementarrowCol(void);

private:
    uint8_t row;
    uint8_t length;
    uint8_t color;
    uint8_t column;
};





#endif /* ARROW_HPP_ */
